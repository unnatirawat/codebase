<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'kaarigarihub');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '|kY~S^}y<S.kjN}<8I5Kic1~Fm&j^3#iS!g]l0+NBCMxVfg_]noO/H8Qs!;cY6@p');
define('SECURE_AUTH_KEY',  'm._N8ORDB=t(0J7kKmjBv[-.|8*@lXASUIWa6OGtO/ik1q{4G WY;gY^as0dn(-h');
define('LOGGED_IN_KEY',    'l71l3Jld/~+..IUES8qQB%6>.A8TGt9#Zf@@:;4~sF$C:8:%/$8RA]n&t%4%T;Bm');
define('NONCE_KEY',        'c<kBtERMw0{q&$~Gx<s)Q>[*kcE@;We`z[v]#r}Rx]0M>/9os5adVzuCEk4dIjCC');
define('AUTH_SALT',        'jn$QU0{v_&@?@K~Q slo:(5+vkqqVknzN6B0I^&6V-wpNo]65L^Qf~g3>|#!5$~<');
define('SECURE_AUTH_SALT', 'jS=qmXpCUz=?G1]nugB*t_hIEuxEMy}m)V#r#==:?c0weU<6*1EJ>]y>f@s})3v^');
define('LOGGED_IN_SALT',   '8bX0}We^Q!K|m1N.05z]Nh,p_xU-jA)XEd*aO|=?B?Zy0&dR5:`oUZvAECs Zsq9');
define('NONCE_SALT',       'F]t&MhU_}H:>@_eV-t3:.qBOWd7`o~jCWlPKI,lOxO%epuECL`LaU{swKl`m4q,/');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
